/*
    CREATE TABLE USERS
    (email varchar(20) primary key, 
    password varchar(15),
    name varchar(15),
    address varchar(15),
    mobile varchar(15));



*/